/**
*
* @name: Adblock Ask 0.0.1
* @copyright: Bart�omiej 'b4rtaz' Tadych, http://b4rtaz.xt.pl/
* @license: http://opensource.org/licenses/gpl-2.0.php GNU Public License
*
*/

//
// var adblock = false;
var browser = [];
browser.gecko = /Gecko/i.test(navigator.userAgent);

// za: http://www.w3schools.com/JS/js_cookies.asp
function get_cookie(name) {
	if(document.cookie.length > 0) {
		start = document.cookie.indexOf(name + "=");
		if (start != -1) {
			start = start + name.length+1;
			end = document.cookie.indexOf(";",start);
			if (end == -1) 
				end = document.cookie.length;
			return unescape(document.cookie.substring(start,end ));
		}
	}
	return false;
}

//
function set_cookie(name, value) {
	document.cookie = name + "=" + value + ";path=/;";
	return;
}


//
function adblock_ask_close(button) {
	button.parentNode.style.display = "none";
	set_cookie("adblockask","1");
	return;
}

if(browser.gecko) {
	// Adblock is endabled.
	if(typeof(abtest1) == "undefined"||typeof(abtest2) == "undefined"||typeof(abtest3) == "undefined") {
		var message = "Dodaj Forex Forum do wyj�tk�w w Adblocku. Tutaj wy�wietla si� tylko jedna reklama. Prosimy, wy��cz blokowanie na forex-nawigator.biz.";
		var faq = "Jak to zrobi�?";
		var faq_url = "/images/jak_to_zrobic.jpg";

		var write = "<div style=\"color:#000; font:11px Tahoma,Arial,Verdana,Serif; padding:8px 0; margin:0; text-align:left; position:absolute; top:0px; left:0px; width:100%; background:#FFFFE7; border-bottom:1px solid #5C5C5C;\">"
			+ "<p style=\"float:left; margin:0 0 0 8px; padding:0;\">"+message+" <a href=\""+faq_url+"\" style=\"padding:0; margin:0; background:none; color:#0000FF;\" target=\"_blank\">"+faq+"</a></p><a onclick=\"adblock_ask_close(this);\""
			+ " style=\"float:right; display:block; cursor:pointer; width:14px; height:14px; text-indent:-2048px; padding:0; mar"
			+ "gin:0 8px 0 0; background:#A31B18 url('data:image/gif;base64,R0lGODlhDgAOAMQAAKMbGMEbCMIbHM8yMJ1FF79OFq9SUdBIR9xWVONvVOhoaPhoaPh4eN+CZMqVcPSLd/GSjdi6k/Crl+6oqPjIyPjYxv//5/j4+P///wAAAAAAAAAAAAAAAAAAAAAAAAAA"
			+ "ACwAAAAADgAOAAAIoAAdGBAAoKDBggQOODjQAMKDhxAfMkhggICEBw0SZEzAUeODAwEkNHhQ4QFHkicLABBZAQOGhxcwVEjwYAAACCNjXtBp8oFKkwgaxMRwQcEBhgMCPEBwQMHQCwkGDEhAcGkCC0R1Ro0KQAECCkQVJIhJ4QBVAAwOfE1wYGrZqQIGZBzQlq7UAQjYGkiwo"
			+ "MGCjoAPGJhgwGYAAIcTFzgQISAAOw==') no-repeat;\">x</a></div>";

		if(!get_cookie("adblockask")) {
			document.write(write);
		}
	}
}
